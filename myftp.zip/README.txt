Students: Craig Butler, Chris Bywaletz, Adrian Popescu

Compilation and Run Instructions:
Put Worker.java in the folder with myftpserver.java
javac myftp
javac myftpserver
java myftp <hostname> <portnumber>
java myftpserver <portnumber>

This project was done in its entirety by Craig Butler, Chris Bywaletz, Adrian Popescu
We hereby state that we have not received unauthorized help of any form.
